# Revision history for tahoe-great-black-swamp-types

## 0.5.0.0 -- 2023-12-21

* First version. Released on an unsuspecting world.
* Types related to Tahoe-LAFS Great Black Swamp split out of tahoe-great-black-swamp package.
